import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'
export const metadata: Metadata={title:'AI COO — Sales & Operations Intelligence',description:'Executive-grade sales and operations intelligence for ambitious businesses.',generator:'v0.app',manifest:'/manifest.webmanifest',icons:{icon:'/icon.svg',apple:'/apple-icon.png'}}
export const viewport:Viewport={width:'device-width',initialScale:1,maximumScale:1,userScalable:false,themeColor:'#09090b'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}{process.env.NODE_ENV==='production'&&<Analytics/>}</body></html>}
