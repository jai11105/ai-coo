import AICooApp from '@/components/ai-coo-app'
export default function Page(){return <AICooApp/>}
