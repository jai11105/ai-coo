export type TxType = 'sale' | 'purchase' | 'expense'
export type Transaction = { id:string; tenantId:string; type:TxType; date:string; item:string; category:string; quantity?:number; unitPrice?:number; buyingCost?:number; amount:number; channel?:string; party?:string; payment?:string; notes?:string; status:'Demo'|'Saved Locally'|'Pending Sync'|'Synced' }
export type Tenant = { id:string; name:string; shortName:string; subtitle:string; industry:string; currency:string; accent:string; initials:string }
export const tenants: Tenant[] = [
 {id:'meta',name:'Meta Horizon & Hardware Hub',shortName:'Meta Horizon',subtitle:'Hardware & B2B sales',industry:'Consumer Electronics',currency:'INR',accent:'violet',initials:'MH'},
 {id:'lakshmi',name:'Sri Lakshmi Mini Mart',shortName:'Sri Lakshmi',subtitle:'Neighborhood grocery',industry:'Retail Grocery',currency:'INR',accent:'emerald',initials:'SL'}
]
const d=(n:number)=>{const x=new Date();x.setDate(x.getDate()-n);return x.toISOString().slice(0,10)}
export const seed: Transaction[] = [
 {id:'MH-1001',tenantId:'meta',type:'sale',date:d(1),item:'Ray-Ban Meta Gen 2',category:'Wearables',quantity:3,unitPrice:32999,buyingCost:24000,amount:98997,channel:'B2B Wholesale',party:'Orbit Labs',payment:'UPI',status:'Demo'},
 {id:'MH-1002',tenantId:'meta',type:'sale',date:d(2),item:'Quest 3S 128GB',category:'VR Headsets',quantity:2,unitPrice:32999,buyingCost:24500,amount:65998,channel:'WhatsApp / Delivery',party:'Aarav Mehta',payment:'Card',status:'Demo'},
 {id:'MH-1003',tenantId:'meta',type:'sale',date:d(4),item:'Meta Quest 3 512GB',category:'VR Headsets',quantity:1,unitPrice:59999,buyingCost:43000,amount:59999,channel:'Counter',party:'Walk-in',payment:'UPI',status:'Demo'},
 {id:'MH-1004',tenantId:'meta',type:'purchase',date:d(3),item:'Quest 3S 128GB',category:'VR Headsets',quantity:12,unitPrice:24500,amount:294000,channel:'Distributor',party:'TechSource India',payment:'Credit',status:'Demo'},
 {id:'MH-1005',tenantId:'meta',type:'purchase',date:d(10),item:'Ray-Ban Meta Gen 2',category:'Wearables',quantity:10,unitPrice:24000,amount:240000,channel:'Distributor',party:'Vision Supply Co.',payment:'Credit',status:'Demo'},
 {id:'MH-1006',tenantId:'meta',type:'expense',date:d(5),item:'Warehouse rent',category:'Operations',amount:28000,channel:'Fixed costs',party:'',payment:'Bank',status:'Demo'},
 {id:'MH-1007',tenantId:'meta',type:'expense',date:d(8),item:'Performance marketing',category:'Marketing',amount:12500,channel:'Growth',party:'',payment:'UPI',status:'Demo'},
 {id:'MH-1008',tenantId:'meta',type:'expense',date:d(12),item:'Team travel',category:'People',amount:8400,channel:'Operations',party:'',payment:'Card',status:'Demo'},
 {id:'SL-2001',tenantId:'lakshmi',type:'sale',date:d(1),item:'India Gate Basmati Rice',category:'Staples',quantity:4,unitPrice:850,buyingCost:650,amount:3400,channel:'Counter',party:'Walk-in',payment:'Cash',status:'Demo'},
 {id:'SL-2002',tenantId:'lakshmi',type:'sale',date:d(2),item:'Fortune Sunflower Oil',category:'Cooking Oil',quantity:6,unitPrice:165,buyingCost:132,amount:990,channel:'WhatsApp / Delivery',party:'Anita Sharma',payment:'UPI',status:'Demo'},
 {id:'SL-2003',tenantId:'lakshmi',type:'sale',date:d(4),item:'Fresh Vegetables Basket',category:'Produce',quantity:8,unitPrice:420,buyingCost:280,amount:3360,channel:'Counter',party:'Walk-in',payment:'Cash',status:'Demo'},
 {id:'SL-2004',tenantId:'lakshmi',type:'purchase',date:d(2),item:'India Gate Basmati Rice',category:'Staples',quantity:40,unitPrice:650,amount:26000,channel:'Wholesale Market',party:'Ravi Foods',payment:'Credit',status:'Demo'},
 {id:'SL-2005',tenantId:'lakshmi',type:'purchase',date:d(6),item:'Fresh Vegetables',category:'Produce',quantity:50,unitPrice:280,amount:14000,channel:'Local Mandi',party:'Koyambedu Market',payment:'Cash',status:'Demo'},
 {id:'SL-2006',tenantId:'lakshmi',type:'expense',date:d(3),item:'Shop electricity',category:'Utilities',amount:3200,channel:'Fixed costs',payment:'Bank',status:'Demo'},
 {id:'SL-2007',tenantId:'lakshmi',type:'expense',date:d(7),item:'Delivery fuel',category:'Delivery',amount:1800,channel:'Operations',payment:'Cash',status:'Demo'},
 {id:'SL-2008',tenantId:'lakshmi',type:'expense',date:d(11),item:'Shop supplies',category:'Operations',amount:1250,channel:'Operations',payment:'UPI',status:'Demo'}
]
